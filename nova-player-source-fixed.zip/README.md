# NOVA PLAYER - cloud build starter

This is the first buildable stage of NOVA PLAYER. It includes device video folder scanning, a video list, basic Media3 playback, and a recent-play highlight. It is not yet the complete feature set.

## Build
The GitHub Actions workflow unpacks `nova-player-source-fixed.zip` and runs Gradle with dependency refresh/retry enabled.

APK output: `app/build/outputs/apk/debug/app-debug.apk`

Package: `com.novaplayer.app`
Minimum Android: 8.0 (API 26)
