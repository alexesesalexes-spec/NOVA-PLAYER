package com.novaplayer.app

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import android.view.ViewGroup
import java.util.Locale

private val Orange = Color(0xFFFF7900)
private val Ink = Color(0xFF171717)
private val Page = Color(0xFFF4F4F6)

data class VideoFile(
    val id: Long,
    val name: String,
    val folder: String,
    val size: Long,
    val duration: Long,
    val uri: Uri
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NovaApp()
        }
    }
}

@Composable
private fun NovaApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var permissionGranted by remember {
        mutableStateOf(hasVideoPermission(context))
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        permissionGranted = result.values.any { it }
    }

    var videos by remember { mutableStateOf<List<VideoFile>>(emptyList()) }
    var selectedFolder by remember { mutableStateOf<String?>(null) }
    var playing by remember { mutableStateOf<VideoFile?>(null) }
    var query by remember { mutableStateOf("") }
    var lastPlayedId by remember { mutableLongStateOf(-1L) }

    LaunchedEffect(permissionGranted) {
        if (permissionGranted) {
            videos = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                loadVideos(context.contentResolver)
            }
            lastPlayedId = context.getSharedPreferences("nova", 0).getLong("last_id", -1L)
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Orange,
            background = Page,
            surface = Color.White
        )
    ) {
        if (!permissionGranted) {
            PermissionScreen {
                val permissions = if (Build.VERSION.SDK_INT >= 34) {
                    arrayOf(
                        Manifest.permission.READ_MEDIA_VIDEO,
                        Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
                    )
                } else if (Build.VERSION.SDK_INT >= 33) {
                    arrayOf(Manifest.permission.READ_MEDIA_VIDEO)
                } else {
                    arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                }
                permissionLauncher.launch(permissions)
            }
        } else if (playing != null) {
            VideoPlayerScreen(
                video = playing!!,
                onBack = { playing = null }
            )
        } else {
            val folders = videos.groupBy { it.folder }
                .toSortedMap()
            val visibleVideos = if (selectedFolder == null) emptyList()
                else videos.filter { it.folder == selectedFolder }
                    .filter { it.name.contains(query, true) }

            Column(
                Modifier.fillMaxSize().background(Page)
            ) {
                Row(
                    Modifier.fillMaxWidth().background(Ink).padding(horizontal = 16.dp, vertical = 18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (selectedFolder != null) {
                        IconButton(onClick = { selectedFolder = null; query = "" }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                    }
                    Column(Modifier.weight(1f)) {
                        Text(
                            selectedFolder ?: "NOVA PLAYER",
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            if (selectedFolder == null) "Folders" else "${visibleVideos.size} videos",
                            color = Color.LightGray,
                            fontSize = 12.sp
                        )
                    }
                    if (selectedFolder != null) {
                        Icon(Icons.Default.Search, contentDescription = null, tint = Color.White)
                    }
                }

                if (selectedFolder == null) {
                    Row(
                        Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("VIDEO FOLDERS", fontWeight = FontWeight.Bold, color = Ink)
                        Text("${folders.size} folders", color = Color.Gray, fontSize = 12.sp)
                    }
                    if (folders.isEmpty()) EmptyState("No videos found on this device")
                    else LazyColumn(contentPadding = PaddingValues(bottom = 20.dp)) {
                        items(folders.entries.toList(), key = { it.key }) { entry ->
                            val totalSize = entry.value.sumOf { it.size }
                            FolderRow(entry.key, entry.value.size, totalSize) {
                                selectedFolder = entry.key
                            }
                        }
                    }
                } else {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                        placeholder = { Text("Search videos") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp)
                    )
                    if (visibleVideos.isEmpty()) EmptyState("No videos in this folder")
                    else LazyColumn(contentPadding = PaddingValues(bottom = 20.dp)) {
                        items(visibleVideos, key = { it.id }) { video ->
                            VideoRow(
                                video = video,
                                recent = video.id == lastPlayedId,
                                onClick = {
                                    lastPlayedId = video.id
                                    context.getSharedPreferences("nova", 0).edit()
                                        .putLong("last_id", video.id).apply()
                                    playing = video
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun hasVideoPermission(context: android.content.Context): Boolean {
    if (Build.VERSION.SDK_INT >= 34) {
        return ContextCompat.checkSelfPermission(
            context, Manifest.permission.READ_MEDIA_VIDEO
        ) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(
                context, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
            ) == PackageManager.PERMISSION_GRANTED
    }
    val permission = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_VIDEO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }
    return ContextCompat.checkSelfPermission(context, permission) ==
        PackageManager.PERMISSION_GRANTED
}

@Composable
private fun PermissionScreen(onRequest: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Ink).padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("NOVA PLAYER", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(12.dp))
        Text("Allow video access to scan your folders", color = Color.LightGray)
        Spacer(Modifier.height(22.dp))
        Button(onClick = onRequest, colors = ButtonDefaults.buttonColors(containerColor = Orange)) {
            Text("Allow access")
        }
    }
}

@Composable
private fun FolderRow(name: String, count: Int, bytes: Long, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp)
            .background(Color.White, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(52.dp).background(Color(0xFFFFE8D5), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Folder, contentDescription = null, tint = Orange, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(name, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Ink)
            Text("$count videos  •  ${formatSize(bytes)}", color = Color.Gray, fontSize = 12.sp)
        }
        Text("›", color = Orange, fontSize = 28.sp)
    }
}

@Composable
private fun VideoRow(video: VideoFile, recent: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp)
            .background(if (recent) Color(0xFFFFE7D2) else Color.White, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(width = 112.dp, height = 76.dp)
                .background(Color(0xFF292929), RoundedCornerShape(9.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("▶", color = Color.White, fontSize = 27.sp)
            Text(
                formatDuration(video.duration),
                Modifier.align(Alignment.BottomEnd).padding(5.dp)
                    .background(Color.Black.copy(alpha = .75f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 5.dp, vertical = 2.dp),
                color = Color.White, fontSize = 10.sp
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(video.name, color = Ink, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(5.dp))
            Text("Video  •  ${formatSize(video.size)}", color = Color.Gray, fontSize = 11.sp)
            if (recent) Text("RECENTLY PLAYED", color = Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun VideoPlayerScreen(video: VideoFile, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember(video.uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(video.uri))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) {
        onDispose {
            player.release()
        }
    }
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(
            Modifier.fillMaxWidth().background(Color(0xFF101010)).padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Text(video.name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = player
                    useController = true
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            modifier = Modifier.fillMaxWidth().weight(1f)
        )
    }
}

private fun loadVideos(resolver: android.content.ContentResolver): List<VideoFile> {
    val result = mutableListOf<VideoFile>()
    val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(
        MediaStore.Video.Media._ID,
        MediaStore.Video.Media.DISPLAY_NAME,
        MediaStore.Video.Media.SIZE,
        MediaStore.Video.Media.DURATION,
        MediaStore.Video.Media.BUCKET_DISPLAY_NAME
    )
    resolver.query(collection, projection, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
        val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
        val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
        val sizeCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
        val durationCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
        val folderCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
        while (c.moveToNext()) {
            val id = c.getLong(idCol)
            result += VideoFile(
                id = id,
                name = c.getString(nameCol) ?: "Unknown video",
                folder = c.getString(folderCol) ?: "Other",
                size = c.getLong(sizeCol),
                duration = c.getLong(durationCol),
                uri = ContentUris.withAppendedId(collection, id)
            )
        }
    }
    return result
}

private fun formatSize(bytes: Long): String {
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb >= 1024) String.format(Locale.US, "%.2f GB", mb / 1024)
    else String.format(Locale.US, "%.1f MB", mb)
}

private fun formatDuration(ms: Long): String {
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%02d:%02d", m, s)
}
