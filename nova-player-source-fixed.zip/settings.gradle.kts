pluginManagement {
    repositories {
        // Primary official repositories
        google()
        mavenCentral()
        gradlePluginPortal()
        // Explicit Maven Central mirror as a fallback for transient repository failures
        maven { url = uri("https://repo1.maven.org/maven2") }
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Explicit mirrors/fallbacks
        maven { url = uri("https://maven.google.com") }
        maven { url = uri("https://repo1.maven.org/maven2") }
    }
}

rootProject.name = "NOVA_PLAYER"
include(":app")
